
package sensoriot;

/**
 *
 * @author Julian2208
 */
public class ModuloWaterPrediction {
  public void predecir(String datosAgua) {
        System.out.println("Predicción de uso de agua: " + datosAgua);
    }
}  

