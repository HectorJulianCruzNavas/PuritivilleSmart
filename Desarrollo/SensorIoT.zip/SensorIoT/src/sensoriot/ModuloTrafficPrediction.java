
package sensoriot;

/**
 *
 * @author Julian2208
 */
public class ModuloTrafficPrediction {
    public void predecir(String datosTrafico) {
        System.out.println("Predicción de tráfico: " + datosTrafico);
    }
}

